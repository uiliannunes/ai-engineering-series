# 🦜🔗 LangChain na Prática — Seu Primeiro Prompt Template

> **Série: Engenharia de IA — Post #1**  
> Por [Uilian Nunes](https://www.linkedin.com/in/uiliannunes/)

Repositório do primeiro post da série **Engenharia de IA**, onde aprenderemos na prática como construir aplicações com LLMs usando LangChain + Groq (API gratuita).

---

## 📁 Estrutura do Projeto

```
📦 ai-engineering-series/
├── 📓 langchain_prompt_template.ipynb   # Notebook principal
├── 📄 requirements.txt                  # Dependências do projeto
├── 🔑 .env.example                      # Modelo de variáveis de ambiente
└── 📖 README.md                         # Este arquivo
```

---

## 🚀 Como Executar

### 1. Clone o repositório
```bash
git clone https://github.com/uiliannunes/ai-engineering-series.git
cd ai-engineering-series
```

### 2. Instale as dependências
```bash
pip install -r requirements.txt
```

### 3. Configure sua chave de API
```bash
cp .env.example .env
# Edite o .env e adicione sua chave da Groq
# Crie gratuitamente em: https://console.groq.com/keys
```

### 4. Abra o notebook
```bash
jupyter notebook langchain_prompt_template.ipynb
```

> 💡 Ou abra direto no **Google Colab** — nenhuma instalação necessária!

---

## 📚 O que você vai aprender

- ✅ O que é LangChain e por que usá-lo
- ✅ Como criar um `PromptTemplate` com variáveis dinâmicas
- ✅ Como conectar ao modelo Llama via Groq (gratuito)
- ✅ Como executar seu primeiro pipeline com LCEL (`template | llm`)

---

## 🔗 Próximos posts da série

| # | Tema | Status |
|---|------|--------|
| 1 | LangChain — Primeiro Prompt Template | ✅ Publicado |
| 2 | Sequential Chains | 🔜 Em breve |
| 3 | RAG (Retrieval-Augmented Generation) | 🔜 Em breve |
| 4 | Agentes Autônomos | 🔜 Em breve |

---

## 📬 Acompanhe a série

Me siga no [LinkedIn](https://www.linkedin.com/in/uiliannunes/) para não perder os próximos posts!

---
*Feito com 🤖 e muito aprendizado.*
